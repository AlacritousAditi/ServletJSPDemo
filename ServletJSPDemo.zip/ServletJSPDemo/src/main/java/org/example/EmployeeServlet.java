package org.example;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import java.io.*;
import java.sql.*;

@WebServlet("/employees")
public class EmployeeServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        String id = request.getParameter("id");

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/servlet_demo", "root", "unknown1");

            String query = (id != null && !id.isEmpty()) ?
                    "SELECT * FROM employees WHERE id=?" :
                    "SELECT * FROM employees";

            PreparedStatement ps = con.prepareStatement(query);
            if (id != null && !id.isEmpty()) {
                ps.setInt(1, Integer.parseInt(id));
            }

            ResultSet rs = ps.executeQuery();

            out.println("<h2>Employee List</h2>");
            out.println("<form method='get'>Search by ID: <input type='text' name='id'> <input type='submit' value='Search'></form>");
            out.println("<table border='1'><tr><th>ID</th><th>Name</th><th>Department</th></tr>");
            while (rs.next()) {
                out.println("<tr><td>" + rs.getInt("id") + "</td><td>" +
                        rs.getString("name") + "</td><td>" +
                        rs.getString("department") + "</td></tr>");
            }
            out.println("</table>");

            con.close();

        } catch (Exception e) {
            e.printStackTrace(out);
        }
    }
}
